/*
 * Aquí deben de ir las variables y los metodos getters y setters. El metodo getResultado (que lanzará la excepción en
 * caso de operador invalido), debe de tener un switch dependiendo del operador que nos haya proporcionado el usuario.
 * Una vez haga el cálculo, el resultado debe de ser almacenado en el operador 1 para poder hacer la incrementalidad.
 * this.operando1 = this.operando1 + this.operando2. El return this.operando1 para mostrar el resultado debe de estar
 * fuera del condicional.
 */
package calculadora;

import java.util.Scanner;

public class Calculadora {
    public static void operar (int x, int y, String op, int resultado){
        x = 0;
        y = 0;
        op = null;
        resultado = 0;
        Scanner scanner = new Scanner(System.in);
            Integer.parseInt(scanner.nextLine());
        scanner.close();
    }
    
}
