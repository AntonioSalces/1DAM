/*
 * Aqui debemos de crear una excepción para cuando el operador sea invalido, de un mensaje de error y vuelva a pedirlo.
 */

package calculadora;

public class OperadorInvalido extends Exception {

}
