import POO.Coche;

public class App {
    public static void main(String[] args) throws Exception {
        Coche doscientosseis = new Coche("Peugeot", 120, 4);
    }
    Coche.informacion(doscientosseis);
}
