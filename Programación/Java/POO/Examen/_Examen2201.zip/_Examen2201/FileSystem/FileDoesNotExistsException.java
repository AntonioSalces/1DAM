package FileSystem;

public class FileDoesNotExistsException extends Exception{
    
}
