package FileSystem;

public class FolderIsFullException extends Exception{
    
}
