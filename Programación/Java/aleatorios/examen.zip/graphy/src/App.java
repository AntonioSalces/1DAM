public class App {
    //Función para generar aleatoriamente el número entre cualquier rango válido especificado.
    private static long numAleatorio(long min, long max){
        return (long)(((Math.random()*max-min)+1)+min);
    }

    //Esta función escribe los guiones por arriba o por abajo de la tabla, que separan los números.
    private static void escribirGuiones(int num){
        for (int i = 1; i <= numeroMayor(num)+1; i++){
            if (i == 1){
                System.out.print(" --- ");
            }else{
                System.out.print("--- ");
            }
        }
    }

    //Función que pinta los asteriscos que van entre las celdas de la tabla. Función aparte porque el código se repite dos veces
    public static void pintarAsteriscos(int i, int numeroFila){
        if (i <= numeroFila) {
            System.out.print(" * |");
        }else{
            System.out.print("   |");
        }
    }

    //Función aparte para voltear numero y que otras funciones no queden tan largas.
    private static long voltear(long num){
        //Multiplico *10 y sumo 1 para que no haya problema al darle la vuelta si hay algun 0.
        num = (num*10)+1;
        long volteado = 0;
        //Este while es el que la da la vuelta al número para posteriormente poder imprimirlo correctamente.
        while (num != 0) {
            volteado = (volteado*10)+num%10;
            num /= 10;
        }
        return volteado;
    }
    //Función para pintar la tabla en blanco y negro.
    private static void pintarTablaNegra(long num){
        //Constante del numero original porque lo utilizaré más adelante, y necesito trabajar con el valor de "num".
        final long NUM_ORIGINAL = num;
        //Llamo a la función de voltear para dar la vuelta al número y pintarlo correctamente.
        long volteado = voltear(NUM_ORIGINAL);
        int resto = 0;
        //Este while es el que imprime el número en vertical con la salida deseada.
        while (volteado != 1){
            resto = (int)volteado%10;
            volteado /= 10;
            //Escribo los guiones por arriba
            escribirGuiones(numeroMayor(NUM_ORIGINAL));
            System.out.println();
            //Guardo el número que sale a la izquierda de la tabla para poder pintar los asteriscos más adelante.
            int numeroFila = Math.abs(resto);
            System.out.printf("| %d |", numeroFila);
            //For que imprime el número con las barras a la derecha e izquierda con el número de columnas necesario.
            for (int i = 1; i <= numeroMayor(NUM_ORIGINAL); i++){
                //Este if hace un salto de línea si es la última celda que cada fila. En otro caso, no lo pintará y seguirá pintando celdas.
                if (i == numeroMayor(NUM_ORIGINAL)){
                    //Llamo a la función para calcular y pintar los asteriscos.
                    pintarAsteriscos(i, numeroFila);
                    System.out.println();
                }else{
                    pintarAsteriscos(i, numeroFila);
                }
            }
        }
        //Escribo los guiones por abajo
        escribirGuiones(numeroMayor(NUM_ORIGINAL));
    }

    //Función para pintar la tabla en blanco y negro.
    private static void pintarTablaColor(long num){
        //Declaro todas las variables con el unicode de las lineas a colocar en la tabla.
        final String SUPERIOR_IZQUIERDA = "\u2554";
        final String SUPERIOR_DERECHA = "\u2557";
        final String INFERIOR_IZQUIERDA = "\u255A";
        final String INFERIOR_DERECHA = "\u255D";
        final String HORIZONTAL = "\u2550";
        final String VERTICAL = "\u2551";
        final String SEPARADOR_IZQUIERDA = "\u2560";
        final String SEPARADOR_DERECHA = "\u2563";
        final String SEPARADOR_ARRIBA = "\u2566";
        final String SEPARADOR_ABAJO = "\u2569";
        final String SEPARADOR_CELDAS = "\u256C";
        //Declado todas las variables con el unicode del color.
        final String RESET = "\033[0m" ;
        final String RED_BACKGROUND = "\033[41m";
        final String GREEN_BACKGROUND = "\033[42m";
        final String BLUE_BACKGROUND = "\033[44m";
        final String PURPLE_BACKGROUND = "\033[45m";
        //Constante del numero original porque lo utilizaré más adelante, y necesito trabajar con el valor de "num".
        final long NUM_ORIGINAL = num;
        //Llamo a la función de voltear para dar la vuelta al número y pintarlo correctamente.
        long volteado = voltear(NUM_ORIGINAL);
        int resto = 0;
        //Escribo los guiones por arriba
            System.out.print(SUPERIOR_IZQUIERDA);
            for (int i = 1; i <= numeroMayor(NUM_ORIGINAL); i++){
            System.out.printf("%s%s%s%s", HORIZONTAL, HORIZONTAL, HORIZONTAL, SEPARADOR_ARRIBA);
            }
            System.out.printf("%s%s%s%s", HORIZONTAL, HORIZONTAL, HORIZONTAL, SUPERIOR_DERECHA);
            System.out.println();
        //Este while es el que imprime el número en vertical con la salida deseada.
        while (volteado != 1){
            resto = (int)volteado%10;
            volteado /= 10;
            //Guardo el número que sale a la izquierda de la tabla para poder pintar los asteriscos más adelante.
            int numeroFila = Math.abs(resto);
            System.out.printf("| %d |", numeroFila);
            //For que imprime el número con las barras a la derecha e izquierda con el número de columnas necesario.
            for (int i = 1; i <= numeroMayor(NUM_ORIGINAL); i++){
                //Este if hace un salto de línea si es la última celda que cada fila. En otro caso, no lo pintará y seguirá pintando celdas.
                if (i == numeroMayor(NUM_ORIGINAL)){
                    if (i <= numeroFila) {
                        if (numeroFila <= 4) {
                            System.out.printf(" %s %s |", BLUE_BACKGROUND, RESET);
                        }else if (numeroFila <= 6 && numeroFila >= 5){
                            System.out.printf(" %s %s |", RED_BACKGROUND, RESET);
                        }else if (numeroFila <= 8 && numeroFila >= 7){
                            System.out.printf(" %s %s |", GREEN_BACKGROUND, RESET);
                        }else{
                            System.out.printf(" %s %s |", PURPLE_BACKGROUND, RESET);
                        }
                    }else{
                        System.out.print("   |");
                    }
                    System.out.println();
                }else{
                    if (i <= numeroFila) {
                        System.out.printf(" %s %s |", BLUE_BACKGROUND, RESET);
                    }else{
                        System.out.print("   |");
                    }
                }
            }
        }
        //Escribo los guiones por abajo.
        System.out.print(INFERIOR_IZQUIERDA);
        for (int i = 1; i <= numeroMayor(NUM_ORIGINAL); i++){
            System.out.printf("%s%s%s%s", HORIZONTAL, HORIZONTAL, HORIZONTAL, SEPARADOR_ABAJO);
        }
        System.out.printf("%s%s%s%s", HORIZONTAL, HORIZONTAL, HORIZONTAL, INFERIOR_DERECHA);
    }

    //Función que nos da el número mayor del número volteado para hacer algunas operaciones con él.
    private static int numeroMayor(long num){
        int max = 0;
        while (num != 0) {
            max = (int)Math.max(max, num%10);
            num /= 10;
        }
        return max;
    }

    public static void main(String[] args) throws Exception {
        try{
            System.out.println("GRAPHIFY");
            System.out.println("===================");
            //Se piden ambos valores para obtener un número aleatorio entre ellos.
            System.out.print("Introduce el valor mínimo del rango: ");
            final long MINIMO = Long.parseLong(System.console().readLine());
            System.out.print("Introduce el valor máximo del rango: ");
            final long MAXIMO = Long.parseLong(System.console().readLine());
            //Para que el programa siga, se deben de seguir las siguientes condiciones.
            if (MINIMO >= 0 && MAXIMO >= 0 && MINIMO < MAXIMO){
                System.out.print("Dibujo la gráfica en blanco y negro o en color (B|C): ");
                String color = System.console().readLine().toUpperCase();
                //Obtengo el número aleatorio entre los dos valores indicados anteriormente.
                long numAleatorio = numAleatorio(MINIMO, MAXIMO);
                if (color.equals("C")) {
                    pintarTablaColor(numAleatorio);
                }else{
                    //Escribimos verticalmente el número aleatorio sacado anteriormente
                    pintarTablaNegra(numAleatorio);
                }
            }else{
                System.out.println("ERROR: los valores del rango deben de ser mayores o iguales a cero, y el primero menor que el segundo.");
            }
        }catch (NumberFormatException e){
            System.out.println("ERROR. Debe de introducir un número válido.");
        }catch (Exception e){
            System.out.println("ERROR. Ha ocurrido un error inesperado.");
        }
    } 
}