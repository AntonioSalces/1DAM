package eticket;

public interface ProductInterface {
    @Override
    boolean equals(Object obj);

    @Override
    String toString();
}
