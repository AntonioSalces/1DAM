package eticket;

public class ProductDoesNotExists extends Exception {
    
}
